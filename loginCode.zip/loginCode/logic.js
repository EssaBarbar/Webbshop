$(document).ready(function() {


     loginUser = function() {
         let url = "requestHandler.php";
         let method = "POST";
         let myData = new FormData();
         myData.set("entity", "users");
         myData.set("endpoint", "login");
         myData.set("email", $("#email").val());
         myData.set("password", $("#password").val());
         makeRequest(url, method, myData, (result) => {
             listOfProducts = result;
             $('#container').hide(2000);

             //console.log(result);
             if (result[0].role == "Admin") {
                 console.log("Admin");
                 window.location.pathname = '/admin/index.php';

             } else {
                 console.log("users");
                 var firstName = result[0].firstName;
                 var lastName = result[0].lastName;
                 var name = firstName + " " + lastName;
                 console.log(name);
                 $('#spanName').text(name);
                 $('#welcome').fadeIn(2000);
             }
         })
     }
})

function loadProducts() {
    let url = "requestHandler.php";
    let method = "POST";
    let myData = new FormData();

    myData.set("entity", "products");
    myData.set("endpoint", "getAllProducts");
    makeRequest(url, method, myData, (result) => {
        console.log(result)
        return result
    })
}

function makeRequest(url, method, formData, callback) {
    fetch(url, {
        method: method,
        body: formData
    }).then((response) => {
        console.log(response)
        return response.json()
    }).then((result) => {
        callback(result)
    }).catch((err) => {
        console.log("Error : ", err);
    })
}

// function addProductsToWebpage() {
//     for (var i = 0; i < listOfProducts.length; i++) {
//         var shopItems = createGameCard(listOfProducts[i])
//         document.getElementById("container").appendChild(shopItems)
//     }
//     changeCounterColor()
// }

loadProducts()();

function createGameCard() {
    var shopItems = document.createElement("div")
    shopItems.classList = "shop-item" + " " + "content-section"

    var shopItemTitle = document.createElement("span")
    shopItemTitle.classList = "shop-item-title"

    var shopItemDescription = document.createElement("p")
    shopItemDescription.classList = "shop-item-description"

    var shopItemImage = document.createElement("IMG")
    shopItemImage.classList = "shop-item-image"
    shopItemImage.setAttribute("src", "./images/pngpictures/pubg.png")
    shopItemImage.setAttribute("width", "200")
    shopItemImage.setAttribute("height", "320")
    shopItemImage.setAttribute("alt", "The Pulpit Rock")

    var shopItemDetails = document.createElement("div")
    shopItemDetails.classList = "shop-item-details"

    var shopItemPrice = document.createElement("span")
    shopItemPrice.classList = "shop-item-price"

    shopItemTitle.innerText = "listOfProducts.productName";
    shopItemDescription.innerText = "listOfProducts.description";
    shopItemImage.innerText = "listOfProducts.pngPicture";
    shopItemPrice.innerText = "listOfProducts.unitPrice" + " " + "kr";

    var shopItemButton = document.createElement("i")
    shopItemButton.innerText = "Lägg till i kundvagn"
    shopItemButton.data = "listOfProducts"
    shopItemButton.classList = "fas fa-shopping-cart" + " " + "btn" + " " + "btn-primary" + " " + "shop-item-button"
        // shopItemButton.onclick = function() {
        //     addData(this.data)
        // }
    shopItems.appendChild(shopItemTitle)
    shopItems.appendChild(shopItemDescription)
    shopItems.appendChild(shopItemImage)
    shopItemDetails.appendChild(shopItemPrice)
    shopItemDetails.appendChild(shopItemButton)
    shopItems.appendChild(shopItemDetails)
        //return shopItems
}