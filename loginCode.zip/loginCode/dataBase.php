<?php

class Database{ 
    function __construct()
    {
        $dsn ='mysql:host=localhost;dbname=enjoy';
        $user = 'root';
        $password = 'root';
        $this->db = new PDO($dsn, $user, $password);
        $this->db->exec("set names utf8");
    }

    
    public function  loginUser($email,$password){  
        $sql = "Select * from users where userId = $email AND password = $password;";
        //$sql = "Select * from users";
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);                
        if(empty($result)){
            throw new Exception("Request not found","501");
            exit;
        }
        return $result;
    }

    public function  getAllProducts(){  
        $sql = "Select * from products;";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);                
        if(empty($result)){
            throw new Exception("Request not found","501");
            exit;
        }
        return $result;
    }
}
?>