<?php
 include("./dataBase.php");

 try{

    // if($_SERVER['REQUEST_METHOD'] === 'POST') {
    //     if($_POST['entity'] == "users") {                        
    //         if ($_POST['endpoint'] == "login") {
    //             $email = $_POST['email'];
    //             $password = $_POST['password'];
    //             $database = new Database();                
    //             $result =$database->loginUser($email,$password);                
    //             echo json_encode($result);                
    //         }             
            
    //         else {
    //             throw new Exception("BBBBBBBBBBBBBBBB", 404);
    //         }

    //     } else {
    //         throw new Exception("AAAAAAAAAAAAA",501);
    //     }
    // } else {
    //     throw new Exception("Not a valid method",405);
    // }
        
    if($_SERVER['REQUEST_METHOD'] === 'POST') {       
        if($_POST['entity'] == "products") {
                            
                if ($_POST['endpoint'] == "getAllProducts") {                    
                    $database = new Database();                
                    $result =$database->getAllProducts();                
                    echo json_encode($result);                
                }                
                else {
                    throw new Exception("BBBBBBBBBBBBBBBB", 404);
                }

        } else {
            throw new Exception("AAAAAAAAAAAAA",501);
        }
    } else {
        throw new Exception("Not a valid method",405);
    }
}catch(Exception $e){
   echo json_encode(array("Message"=> $e->getMessage(), "Status"=> $e->getCode()));
}

?>