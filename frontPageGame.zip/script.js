function makeRequest(url, method, formData, callback){

    fetch(url, {
        method: method,
        body: formData
    }).then((response) => {
        console.log(response)
        return response.json()
    }).then((result) => {
        callback(result)
    }).catch((err) => {
        console.log("Error : ",err); 
    })
}
function getAllProduct(){
    var myData = new FormData();
    myData.append("entity","product");
    myData.append("endpoint","getAllProducts");
    makeRequest("productHandler.php", "POST", myData, (result) =>{     

        document.getElementById("productList").innerText = result;
/*         var productList = document.getElementById("productList").innerText;
        for (var i = 1; i < productList.length; i++) {
            document.getElementById("productList").innerText;
        } */
        console.log(result);
    })
}
function getPCProducts(){
    var myData = new FormData();
    myData.append("entity","product");
    myData.append("endpoint","getPCProducts");
    makeRequest("productHandler.php", "POST", myData, (result) =>{
        document.getElementById("productList").innerText = result;
        console.log(result);
    })
}
function getPs4Products(){
    var myData = new FormData();
    myData.append("entity","product");
    myData.append("endpoint","getPs4Products");
    makeRequest("productHandler.php", "POST", myData, (result) =>{
        document.getElementById("productList").innerText = result;
        console.log(result);
    })
}
function getXboxProducts(){
    var myData = new FormData();
    myData.append("entity","product");
    myData.append("endpoint","getXboxProducts");
    makeRequest("productHandler.php", "POST", myData, (result) =>{
        document.getElementById("productList").innerText = result;
        console.log(result);
    })
}