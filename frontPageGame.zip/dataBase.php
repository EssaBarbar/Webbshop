<?php

class Database
{


    function __construct()
    {
        $dsn = 'mysql:host=localhost;dbname=enjoy';
        $user = 'root';
        $password = 'root';
         $this->db = new PDO($dsn, $user, $password);
        $this->db->exec("set names utf8"); 
/*         $pdo = new \PDO($dsn, $user, $password);
        $pdo->exec("set names utf8");  */

    }
    public function getAllProductData()
    {

        $sql = "SELECT * FROM products;";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getPCProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='3';";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        /*  while ($r = $result->fetch()) {
            echo sprintf('%s <br/>', $r['ProductName']);
        } */
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getPs4ProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='2';";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getXboxProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='1';";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
}

?>