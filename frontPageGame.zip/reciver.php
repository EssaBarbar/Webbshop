<?php
 //include("./dataBase.php");
?>

<?php
class reciver{
public function getAllProductData()
    {

        $sql = "SELECT * FROM products;";        
        $sqlQuery = $pdo->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getPCProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='3';";        
        $sqlQuery = $pdo->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getPs4ProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='2';";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
    public function getXboxProductsData()
    {

        $sql = "SELECT * FROM products where `CategoryID` ='1';";        
        $sqlQuery = $this->db->prepare($sql);
        $sqlQuery->execute();
        $result = $sqlQuery->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        if (empty($result)) {
            throw new Exception("Request not found", "501");
            exit;
        }
    }
}
    ?>