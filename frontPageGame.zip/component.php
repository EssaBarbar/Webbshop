<?php
 
 function inputElement($placeholder, $name, $value,$class,$text){
    $ele = "
               <input type='$text' class='$class' name='$name' value='$value' autocomplete=\"off\" placeholder='$placeholder' class=\"form-control\" id=\"inlineFormInputGroup\" placeholder=\"Username\">
    
    ";
    echo $ele;
}

function buttonElement($btnid, $styleclass, $text, $name, $attr,$onclick){
    $btn = "
        <button name='$name' '$attr' class='$styleclass' id='$btnid' onclick='$onclick'>$text</button>
    ";
    echo $btn;
}
function formdataLabel($id,$name,$value,$placeholder,$class,$type,$text, $required){
    $formdataLabel ="
                <label class='$class' id='$id' name='$name' value='$value' placeholder='$placeholder' type='$type '$required'>$text</label>

           ";

echo  $formdataLabel;
}
