<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
/*         $(document).ready(function(){
        $("#signup").click(function(){
            $("#signupform").hide(1000);
        });
            $("#login").click(function(){
            $("#loginform").show(1000);
        });
        }); */
    </script>
</head>

<body>
    <header></header>
    <div id="main">
        <article id="outputProduct">
            <div id="productList">

            </div>
        </article>
        <nav id="navLeft">
            <h3>Category</h3>
            <!--   <ul>
                <li><button  onclick="getAllProduct()"> product</button></li>
              
                <li><button>PS4</button></li>
                <li><button>Xbox</button>></li>
            </ul>  -->
            <ul>
                <li><?php buttonElement("", "", "product", "product", "", "getAllProduct()") ?></li>
                <li><?php buttonElement("", "", "PC", "PC", "", "getPCProducts()") ?></li>
                <li><?php buttonElement("", "", "PS4", "PS4", "", "getPs4Products()") ?></li>
                <li><?php buttonElement("", "", "XBox", "XBox", "", "getXboxProducts()") ?></li>
            </ul>
        </nav>
        <i class="fas fa-shopping-cart"></i>
        <aside id="aside">
        <div class="login-item">
            <form action="" method="post" class="form form-login">
                <div class="form-field">
                    <!--  <label class="user" for="login-username"><span class="hidden">Username</span></label> -->
                    <?php formdataLabel("login-username", "", "", "Username", "user", "text", "Username", "required") ?>
                    <!--  <input id="login-username" type="text" class="form-input" placeholder="Username" required> -->
                    <?php inputElement("Username", "user", "", "form-input", "Username") ?>
                </div>
                <!-- formdatafield($id,$name,$value,$placeholder,$class,$type) -->

                <div class="form-field">
                    <!--  <label class="lock" for="login-password"><span class="hidden">Password</span></label> -->
                    <?php formdataLabel("password", "", "", "password", "lock", "password", "Password", "required") ?>
                    <input id="login-password" type="password" class="form-input" placeholder="Password" required>
                </div>

                <div class="form-field">
                    <input type="submit" value="Log in" class="loginsubmit">
                    <a href="registerUser.php" class="signup">Sign Up </a>
                </div>

            </form>
        </div>
        </aside>
    </div>
    <script src="script.js"></script>
</body>

</html>