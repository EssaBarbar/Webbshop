<?php
include("./dataBase.php");
$data = file_get_contents("php://input");
try{
    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        if($_POST['entity'] =="product") {
 
            if($_POST['endpoint'] =="getAllProducts"){
             
                $database = new Database();
                $result = $database->getAllProductData(); 
                echo json_encode($result);
            
            }
            else if($_POST['endpoint'] =="getPCProducts"){
             
                $database = new Database();
                $result = $database->getPCProductsData(); 
                echo json_encode($result);
            
            }
            else if($_POST['endpoint'] =="getPs4Products"){
             
                $database = new Database();
                $result = $database->getPs4ProductsData(); 
                echo json_encode($result);
            
            }
            else if($_POST['endpoint'] =="getXboxProducts"){
             
                $database = new Database();
                $result = $database->getXboxProductsData(); 
                echo json_encode($result);
            
            }
            else {
                throw new Exception("BBBBBBBBBBBBBBBB",507);
            }

        } else {
            throw new Exception("AAAAAAAAAAAAA",501);
        }

    }
    else {
        throw new Exception("Not a vailid method",405);
    }
    
}catch(Exception $e){
   echo json_encode(array("Message"=> $e->getMessage(), "Status"=> $e->getCode()));
}

?>
