<?php
include "./component.php";
include "./product.php";
?>
    
